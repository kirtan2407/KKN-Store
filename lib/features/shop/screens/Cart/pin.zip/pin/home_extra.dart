import 'package:flutter/material.dart';

class HomeExtra extends StatelessWidget {
  const HomeExtra({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(backgroundColor: Colors.amber,));
  }
}
